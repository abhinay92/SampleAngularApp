angular.module("EmpMgmtApp.controllers")
	.controller("EmpMgmtDeleteController",function($scope,$route,serviceApi,$rootScope){
		$rootScope.activeRoute = "Delete";
		$scope.data = [	{"id":"A1000","firstname":"Heather","lastname":"Bell","email":"Heather@sample.com","role":"Software Engineer","doj":"23-February-2017"},
						{"id":"A1001","firstname":"Andrea","lastname":"Dean","email":"Dean@sample.com","role":"Delivery Manager","doj":"13-June-2017"},
						{"id":"A1002","firstname":"Peter","lastname":"Barnes","email":"Barnes@sample.com","role":"Software Engineer","doj":"16-July-2017"},
						{"id":"A1004","firstname":"Harry","lastname":"Bell","email":"Bell@sample.com","role":"Director","doj":"10-August-2017"},
						{"id":"A1005","firstname":"Deborah","lastname":"Burns","email":"Burns@sample.com","role":"Technical Lead","doj":"5-May-2017"},
						{"id":"A1006","firstname":"Larry","lastname":"Kim","email":"kim@sample.com","role":"Pricipal Consultant","doj":"12-September-2017"},
						{"id":"A1007","firstname":"Jason","lastname":"Wallace","email":"wallace@sample.com","role":"Chief Architect","doj":"1-August-2017"}];
		   
		  $scope.viewby = 7;
		  $scope.totalItems = $scope.data.length;
		  $scope.currentPage = 1;
		  $scope.itemsPerPage = $scope.viewby;
		  $scope.maxSize = 5;
		  $scope.emUserDetails = null;

		  $scope.setPage = function (pageNo) {
		    $scope.currentPage = pageNo;
		  };

		  $scope.pageChanged = function() {
		    console.log('Page changed to: ' + $scope.currentPage);
		  };

		  $scope.setItemsPerPage = function(num) {
		  	$scope.itemsPerPage = num;
		  	$scope.currentPage = 1; 
		  };

		  $scope.getUserDetails = function(user,index){
		  	$scope.emUserDetails = user;
		  	$scope.editIndex = index;
		  };

		  $scope.deleteAccount = function(user) {
		  		$scope.data.splice($scope.editIndex,1);
		  		$scope.emUserDetails = null;
		  }

	});