angular.module("EmpMgmtApp.controllers")
	.controller("EmpMgmtHeaderController", function($scope,serviceApi,$route){
		 
		
	});