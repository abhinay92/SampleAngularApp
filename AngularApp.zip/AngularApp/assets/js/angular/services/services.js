angular.module("EmpMgmtApp.services",[]).
	factory("serviceApi",function($http){
		var serviceResponse = {};
		return serviceResponse;
	});