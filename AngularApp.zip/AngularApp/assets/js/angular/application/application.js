angular.module("EmpMgmtApp",[
	"EmpMgmtApp.controllers",
	"EmpMgmtApp.services",
	"ngRoute",
	"ui.bootstrap"
	]).config(['$routeProvider',function($routeProvider){
		$routeProvider.
		when("/home",{controller :"EmpMgmtHomeController",templateUrl:"features/home.html"}).
		when("/create",{controller :"EmpMgmtCreateController",templateUrl:"features/create.html"}).
		when("/update",{controller:"EmpMgmtUpdateController", templateUrl:"features/update.html"}).
		when("/delete",{controller:"EmpMgmtDeleteController",templateUrl:"features/delete.html"}).
		otherwise({ redirectTo : "/home"});
	}]);